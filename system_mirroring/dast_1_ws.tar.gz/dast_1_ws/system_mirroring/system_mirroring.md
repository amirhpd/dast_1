## System Mirroring
Here is the procedure to replicate the working system on another computer by installing all required packages.

To install on a new computer:

1. Install ROS2-Humble on Ubuntu 22.04 LTS

2. Run the _install_ros_packages.sh_ to install ROS2 packages:

    ```
    chmod +x install_ros_packages.sh
    ./install_ros_packages.sh
    ```

3. Install Python packages:
    ```
    pip install -r installed_python_packages.txt
    ```

4. 